For documentation please "pydoc overload". The same documentation is available
at http://pypi.python.org/pypi/overload

To run its tests use "python -m overload".

To install under Python 3::

    % python3 setup.py install

or the easier::

    % pip install overload

See the module for contact and license info.
